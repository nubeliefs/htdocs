//statcounter
var sc_project = 12706895;
var sc_invisible = 0;
var sc_security = "dfb6332b";
var sc_text = 2;
var scJsHost = "https://";
document.write("<sc" + "ript type='text/javascript' src='" +
    scJsHost +
    "statcounter.com/counter/counter.js'></" + "script>");