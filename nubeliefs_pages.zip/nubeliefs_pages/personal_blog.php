<body>

    <div class="container-fluid" id="space">

        <div class="row">
            <div class="col-sm-2"></div>

            <div class="col-sm-8">
                <p></p>
                <p></p>
                <h1 class="display-2">Personal blog</h1>
                <p class="lead text-justify">
                   Watch all those we post randomly from all areas of our life!
                </p>
                
                <p class="lead text-justify">
                <div class="tumblr-post" data-href="https://embed.tumblr.com/embed/post/-S8ZpnWeZv_SnwMDH6MzSA/675456175304802304" data-did="7089d76e447711eac3ff1314134be9bacd4a2d39"><a href="https://non-universal-beliefs.tumblr.com/post/675456175304802304/smell-a-wonderful-sense">https://non-universal-beliefs.tumblr.com/post/675456175304802304/smell-a-wonderful-sense</a></div>  <script async src="https://assets.tumblr.com/post.js"></script>
                </p>

            </div>
        </div>
    </div>

</body>