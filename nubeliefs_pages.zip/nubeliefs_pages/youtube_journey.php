<body>

  <div class="container-fluid" id="space">

    <div class="row">
      <div class="col-sm-2"></div>

      <div class="col-sm-8">
        <p></p>
        <p></p>
        <h1 class="display-2">Journey to the YouTube</h1>
        <p class="lead text-justify">
          Our goal is to present our unbiased theories to the world
          and for this we find YouTube as the best platform.
          With all our dedication and hardword we do research on topics
          and try to present them in the form of videos, so that it can
          go straight to your head and thereby it solves our purpose.

        </p>
        <h1 class="display-6">Please subscribe</h1>
        <p class="lead">
          You can subscribe to this channel by clicking on the below button.
        </p>
        <br><br>
        <script src="https://apis.google.com/js/platform.js"></script>

        <div class="g-ytsubscribe" data-channelid="UCD-iHcCt7n1bmIRZn0YceLA" data-layout="full" data-count="default">
        </div>
        <br><br>
        <br>
        <h1 class="display-6">Content that matters!</h1>
        <p class="lead text-justify">
          Please watch our amazing videos right below and do like, share and subscribe.
        </p>

        <br><br>
        <h1 class="display-6">Stay tuned!</h1>
        <br><br>
        <!-- Carousel -->
        <div id="demo" class="carousel slide" data-bs-ride="carousel">

          <!-- Indicators/dots -->
          <div class="carousel-indicators">
            <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
          </div>

          <!-- The slideshow/carousel -->
          <div class="carousel-inner">
            <div class="carousel-item active">
              <iframe class="container-fluid" width="560" height="315" src="https://www.youtube.com/embed/qQFWhQuTDvk"
                title="YouTube video player" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>

            </div>
            <div class="carousel-item">
              <iframe class="container-fluid" width="560" height="315" src="https://www.youtube.com/embed/lBwGbDotLCU"
                title="YouTube video player" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>

            </div>
            <div class="carousel-item">
              <iframe class="container-fluid" width="560" height="315" src="https://www.youtube.com/embed/XxvPxkXb9Qc"
                title="YouTube video player" frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen></iframe>

            </div>
          </div>



          <!-- Left and right controls/icons -->
          <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
          </button>
        </div>

        <br><br><br><br>
        
        <blockquote class="blockquote text-right">
          <p class="mb-0 text-justify"> Please suggest us for any improvement areas or something you appreciate. Your feedback matter
            to us.
          </p>
          <br>
          <footer class="blockquote-footer">Non universal beliefs <cite title="Source Title">(nubeliefs)</cite>
          </footer>
        </blockquote>
        <br><br><br><br>
      </div>

    </div>

  </div>

</body>