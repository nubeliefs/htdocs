<body>

    <div class="container-fluid" style="background-color: skyblue;">

        <div class="row">
            <div class="col-sm-2"></div>

            <div class="col-sm-8">
                <p></p>
                <p></p>
                <h1 class="display-2">News stories</h1>
                <p class="lead">
                    Watch news from valid source just right below
                </p>
                                
            </div>
        </div>
    </div>

</body>