<body>

    <div class="container-fluid" id="space">

        <div class="row">
            <div class="col-sm-2"></div>

            <div class="col-sm-8">
                <p></p>
                <p></p>
                <h1 class="display-2">Dreams or the nightmares?</h1>
                <p class="lead text-justify">
                    Dreams are the most beautiful gift provided to human beings
                    which let us feel that we are actually experiencing that
                    but that is only true until we are sleeping.
                </p>
                <p class="lead text-justify">
                    Based on the event happens in our day to day life we all experiences
                    some good or bad dreams. On an average 2 out of 10 dreams we are only
                    able to remember and rest we do forget. Hence, lets discuss few dreams
                    which are an interesting one and a good read.
                </p>
                <br><br>
                <h1 class="display-6">Airplane v/s Ocean!</h1>
                <p class="lead text-justify">
                    It all started when I was travelling in a bus, and while I fall asleep
                    I had this dream of travelling in an airplane.
                    An airplane sliding down to the ocean.
                    I saw myself flying in an ocean, the plane was too fast in speed.
                    Pilot was trying to take off but I am not sure what was actually pulling it towards the surface of
                    ocean.
                    Literally I got very scared but enjoyed this adventurous dream at the same time.
                </p>
                
                <br><br>
                <h1 class="display-6">Flying Minidor (a vehicle)!</h1>
                <p class="lead">
                    This dream seems to be very horryfying one as it let our life endangered...
                    The Minidor was literally flying from top of the hill down to the road...
                    I was just seeing them all getting smashed on the ground...
                    No loss of life...
                    No shattering minidors..
                    Everything was jumping like a ball...
                    It was a good but scary dream altogether...To be remembered!
                </p>
               
                <br><br>
                <blockquote class="blockquote text-right">
                    <p class="mb-0">Keep watching this space for more such interesting dream stories.
                        Also, you can drop us an email with subject "dream stories" if you had any of your interesting
                        dream stories
                        which can be shared so that we can post it here with all due credits. Please visit "Contact Us"
                        page to see our email address.
                    </p>
                    <br>
                    <footer class="blockquote-footer">Non universal beliefs <cite
                            title="Source Title">(nubeliefs)</cite>
                    </footer>
                </blockquote>
                <br><br>


            </div>

        </div>



    </div>
</body>