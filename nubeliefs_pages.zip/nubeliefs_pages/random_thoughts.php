<body>

    <div class="container-fluid" id="space">

        <div class="row">
            <div class="col-sm-2"></div>

            <div class="col-sm-9">
                <p></p>
                <p></p>
                <h1 class="display-2">Blogs & more!</h1>
                <p class="lead text-justify">
                    Hi there, lets open up to a discussion.
                </p>
                <br> <br>

                <div class="row">
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-body" style="background-color:#9400d3; color:white;">
                                <h5 class="card-title">Personal Blogs</h5>
                                <p class="card-text text-justify">This blog category will features all the random stuffs we see
                                    around the world, strange stories, How to do things?, delecious recepies,
                                    wise words, etc. Please click on continue button to proceed to personal blogs. </p>
                                <a class="text-white float-right font-weight-bold" href="#!personal_blog">Continue</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-body" style="background-color:#c154c1; color:white;">
                                <h5 class="card-title">Technology Blogs</h5>
                                <p class="card-text text-justify">This blog will feature various techology related stuffs for e.g.
                                    science
                                    technology, information technology, artificial intelligence, space technology, bio
                                    technology
                                    , and many more. Please click on continue button to proceed to technological blogs.
                                </p>
                                <a class="text-white float-right font-weight-bold" href="#!technology_blog">Continue</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-body" style="background-color:#E81828; color:white;">
                                <h5 class="card-title">Dream Journal</h5>
                                <p class="card-text text-justify">Dreams are the most beautiful gift provided to human beings which
                                    let us feel that we are actually experiencing that but that is only true until we
                                    are sleeping. Based on the event happens in our day to day life we all experiences 
                                    some good or bad dreams. On an average 2 out of 10 dreams we are only able to remember
                                    and rest we do forget. Hence, lets discuss few dreams which are an interesting one and a good
                                    read.. Please click on continue link to proceed to Dream journal.
                                </p>
                                <a class="text-white float-right font-weight-bold" href="#!technology_blog">Continue</a>
                            </div>
                        </div>
                    </div>

                </div>


                <br> <br>


            </div>

        </div>

    </div>



</body>