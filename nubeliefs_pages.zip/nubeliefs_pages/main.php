<body>

    <div class="container-fluid" id="space">

        <div class="row">
            <div class="col-sm-2">
                
            </div>

            <div class="col-sm-8">
                <p></p>
                <p></p>
                <h1 class="display-2">Dear visitors,</h1>
                <p class="lead text-justify">
                    Coming to an end? Just think again.
                    Deep dive into an Ocean and touch the coral reefs.
                    Welcome to non universal beliefs.
                </p>
                <br>
                <h1 class="display-6">What is non universal beliefs?</h1>
                <p class="lead text-justify">
                    <?php include 'main_text.txt';?>
                </p>
                <br>
                <h1 class="display-6">What is nubeliefs?</h1>
                <p class="lead text-justify">
                    "nubeliefs" is a word created from nonuniversal beliefs (n: non ; u: universal ; beliefs: beliefs)
                </p>
                <br>
            </div>

        </div>



    </div>

</body>
